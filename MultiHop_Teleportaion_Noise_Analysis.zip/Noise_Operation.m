function [rho_noisy] = Noise_Operation(rho_in,Noise_Type,eta)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
I = eye(2);
X = [0 1;1 0];
Z = [1 0;0 -1];
Y = [0 -1i;1i 0];
q = log2(length(rho_in));
if(length(eta)~= q-2)
%     disp(['Please enter ',num2str(q-2),' noise paprameter.']);
end

syms e_BF e_PF e_BPF e_AD e_PD real positive

% Quantum Noise Kraus Operators
% Bit-Flip Noise
E_BF_0(e_BF) = sqrt(1-e_BF).*I;E_BF_1(e_BF) = sqrt(e_BF).*X;
% Phase-Flip Noise
E_PF_0(e_PF) = sqrt(1-e_PF).*I;E_PF_1(e_PF) = sqrt(e_PF).*Z;
% Bit & Phase-Flip Noise
E_BPF_0(e_BPF) = sqrt(1-e_BPF).*I;E_BPF_1(e_BPF) = sqrt(e_BPF).*Y;
% Amplitude-Damping Noise
E_AD_0(e_AD) = [1 0;0 sqrt(1-e_AD)];E_AD_1(e_AD) = [0 sqrt(e_AD);0 0];
% Phase-Damping Noise
E_PD_0(e_PD) = [1 0;0 sqrt(1-e_PD)];E_PD_1(e_PD) = [0 0;0 sqrt(e_PD)];

if(Noise_Type=="BF")
    disp("Bit-Flip Noise Analysis")
    E0 = kron(I,I);
    E1 = kron(I,I);
    for i=1:q-2
        E0 = kron(E0,(E_BF_0(eta(i))));
        E1 = kron(E1,(E_BF_1(eta(i))));
    end
    rho_noisy = E0*rho_in*conj(E0')+E1*rho_in*conj(E1');
end
    
if(Noise_Type=="PF")
    disp("Phase-Flip Noise Analysis")
    E0 = kron(I,I);
    E1 = kron(I,I);
    for i=1:q-2
        E0 = kron(E0,(E_PF_0(eta(i))));
        E1 = kron(E1,(E_PF_1(eta(i))));
    end
    rho_noisy = E0*rho_in*conj(E0')+E1*rho_in*conj(E1');
end

if(Noise_Type=="BPF")
    disp("Bit and Phase-Flip Noise Analysis")
    E0 = kron(eye(2),eye(2));
    E1 = kron(eye(2),eye(2));
    for i=1:q-2
        E0 = kron(E0,(E_BPF_0(eta(i))));
        E1 = kron(E1,(E_BPF_1(eta(i))));
    end
    rho_noisy = E0*rho_in*conj(E0')+E1*rho_in*conj(E1');
end


if(Noise_Type=="AD")
    disp("Amplitude-Damping Noise Analysis")
    E0 = kron(eye(2),eye(2));
    E1 = kron(eye(2),eye(2));
    for i=1:q-2
        E0 = kron(E0,(E_AD_0(eta(i))));
        E1 = kron(E1,(E_AD_1(eta(i))));
    end
    rho_noisy = E0*rho_in*conj(E0')+E1*rho_in*conj(E1');
end

if(Noise_Type=="PD")
    disp("Phase-Damping Noise Analysis")
    E0 = kron(eye(2),eye(2));
    E1 = kron(eye(2),eye(2));
    for i=1:q-2
        E0 = kron(E0,(E_PD_0(eta(i))));
        E1 = kron(E1,(E_PD_1(eta(i))));
    end
    rho_noisy = E0*rho_in*conj(E0')+E1*rho_in*conj(E1');
end

end


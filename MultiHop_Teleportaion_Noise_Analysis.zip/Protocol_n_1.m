clc
clear
close all


syms a0 a1 b0 b1 real

ket0 = [1;0];
ket1 = [0;1];
ket00 = kron(ket0,ket0);
ket01 = kron(ket0,ket1);
ket10 = kron(ket1,ket0);
ket11 = kron(ket1,ket1);
ket0000 = kron(ket00,ket00);
ket0101 = kron(ket01,ket01);
ket1010 = kron(ket10,ket10);
ket1111 = kron(ket11,ket11);
ket0110 = kron(ket01,ket10);
ket1001 = kron(ket10,ket01);
ket00000000 = kron(,);ket00010010 = kron(,);ket00100001 = kron(,);ket00110011 = kron(,);
ket01000100 = kron(,);ket01010110 = kron(,);ket01100101 = kron(,);ket01110111 = kron(,);
ket00000000 = kron(,);ket00000000 = kron(,);ket00000000 = kron(,);ket00000000 = kron(,);
ket00000000 = kron(,);ket00000000 = kron(,);ket00000000 = kron(,);ket00000000 = kron(,);

% Step 0
Psi_A = a0.*ket0+a1.*ket1;
Psi_B = b0.*ket0+b1.*ket1;
Psi_ch1 = 0.5.*(ket0000+ket0101+ket1010+ket1111);
Psi_ch2 = 0.5.*(ket0000+ket0110+ket1001+ket1111);
Psi_ch = 0.25.*(ket00000000+ket00010010+ket00100001+ket00110011+...
                ket01000100+ket01010110+ket01100101+ket01110111+...
                ket10001000+ket10011010+ket10101001+ket10111011+...
                ket11001100+ket11011110+ket11101101+ket11111111);
Psi_C = ket00;
Psi_sys = kron(kron(kron(Psi_A,Psi_B),Psi_C),Psi_ch);

%Step 1







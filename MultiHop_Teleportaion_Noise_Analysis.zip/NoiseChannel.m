function [rho_noisy] = NoiseChannel(rho, Qubits, Type, eta)
%UNTITLED3 Summary of this function goes here
%   Detailed explanation goes here
% rho_in : Density Matrix of Quantum System
% Qubits : Noisy qubits, for example: CQ = [0,0,1,1] q3 and q4 are noisy
% Type : Noise Type AD = Amplitude-Damping, PD=Phase-Damping, BF=BitFlip, ...
% eta : Noise Probability eta=[0,1]
% rho_noisy : Noisy Density Matrix of Quantum System

E_AD_0 = [1 0;0 sqrt(1-eta)]; 
E_AD_1 = [0 sqrt(eta);0 0];


switch Type
    case 'AD'
        disp('Applying Amplitude-Damping noise');
    case 'PD'
        disp('Applying Phase-Damping noise');
    case 'BF'
        disp('Applying BitFlip noise');
    otherwise
        disp('Please select on of the defined quantum noise (AD:Amplitude-Damping, PD:Phase-Damping noise, BF:BitFlip)!')
end
end


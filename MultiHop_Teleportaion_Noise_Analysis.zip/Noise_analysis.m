
syms a0 a1 real
syms eta_A eta_B eta_h1 eta_h2 eta_h3 eta_h4 eta_h5 eta_h6 positive real


ket0 = [1;0];
ket1 = [0;1];

I = eye(2);
X = [0 1;1 0];
Z = [1 0;0 -1];
Y = [0 -1i;1i 0];

switch hop
    case 0
        eta = [eta_A eta_B];
    case 1
        eta = [eta_A eta_h1 eta_h2 eta_B];
    case 2
        eta = [eta_A eta_h1 eta_h2 eta_h3 eta_h4 eta_B];
    case 3
        eta = [eta_A eta_h1 eta_h2 eta_h3 eta_h4 eta_h5 eta_h6 eta_B];
    otherwise
        disp("ERROR!!")
end

q = 4+2*hop;
r = pow2(q);

% Step 0: Prepration
% Quantum state: |A> |C> |a> |h_1> |h_2> ... |h_n> |b>
Psi_sys = ket0;
i = 0;
while(i<3+2*hop)
    Psi_sys = kron(Psi_sys,ket0);
    i=i+1;
end
rho_sys = Psi_sys*conj(Psi_sys');

% Step 1: Quantum Channel
Psi_A = a0.*ket0+a1.*ket1;
rho_1 = Psi_A*conj(Psi_A');
Psi_1 = Psi_A;
[rho_2,Psi_2] = rho_ch(r);
% Ideal Channel
rho_sys  = kron(rho_1,rho_2);
Psi_sys  = kron(Psi_1,Psi_2);
% Noisy Channel

rho_noisy = Noise_Operation(rho_sys,Noise_Type,eta);

% Step 3: Alice measurement and operation
U3 = U_Alice(r);
% Ideal Channel
rho_sys = U3*rho_sys*conj(transpose(U3));
Psi_sys = U3*Psi_sys;
% Noisy Channel
rho_noisy = U3*rho_noisy*conj(transpose(U3));


% Step 4: Multihop communication process
h=0;
while(h<hop)
    [U4] = U_Hop(r,h);
    % Ideal Channel
    rho_sys = U4*rho_sys*conj(transpose(U4));
    Psi_sys = U4*Psi_sys;
    % Noisy Channel
    rho_noisy = U4*rho_noisy*conj(transpose(U4));
    h=h+1;
%     disp("Done!!")
end


% Step 5: Charlie measurement and operation
U5 = U_Charlie(r);
% Ideal Channel
rho_sys = (U5*rho_sys*conj(transpose(U5)));
Psi_sys = (U5*Psi_sys);

% Noisy Channel
rho_noisy = (U5*rho_noisy*conj(transpose(U5)));


alpha0 = cos(theta);
alpha1 = sin(theta);

% Ideal Channel
rho_sys=subs(rho_sys,a0,alpha0);
rho_sys=subs(rho_sys,a1,alpha1);
Psi_sys=subs(Psi_sys,a0,alpha0);
Psi_sys=subs(Psi_sys,a1,alpha1);

% Noisy Channel
rho_noisy=subs(rho_noisy,a0,alpha0);
rho_noisy=subs(rho_noisy,a1,alpha1);

P0 = trace(rho_sys(1:2:end,1:2:end));
P1 = trace(rho_sys(2:2:end,2:2:end));

% Fidilety Calculation
F = simplify(conj(Psi_sys')*rho_noisy*Psi_sys);
disp('Fidelity is: ');
disp(F);

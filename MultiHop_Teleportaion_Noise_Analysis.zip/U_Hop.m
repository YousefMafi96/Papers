function [U] = U_Hop(r,h)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
I = eye(2);
Hadamard = 1/sqrt(2).*[1 1;1 -1];
CNOT = [1 0 0 0;0 1 0 0;0 0 0 1;0 0 1 0];
q = log2(r);
H = (q-4)/2;

U0 = kron(Hadamard,I)*CNOT;
U_BSM =  kron(kron(kron(eye(8),eye(pow2(2*h))),U0),eye(pow2(2*(H-h-1)+1)));

U1 = zeros(8);
U1(1,1)=1;U1(2,2)=1;U1(4,3)=1;U1(3,4)=1;
U1(5,5)=1;U1(6,6)=-1;U1(8,7)=-1;U1(7,8)=1;

U = (kron(kron(kron(eye(8),eye(pow2(2*h))),U1),eye(pow2(2*(H-h-1)))))*U_BSM;

end


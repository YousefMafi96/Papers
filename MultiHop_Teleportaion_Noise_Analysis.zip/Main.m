clc
clear 
close all

% Number of Hops: hop={0,1,2,3}
hop = 1;

% Quantum noise types: 
% 'AD'- Amplitude_damping
% 'PD'- Phase_damping, 
% 'BF'- Bit-Flip
% 'PF'- Phase-Flip
% 'BPF'- Bit and Phase-Flip
Noise_Type = 'PD';

% Input state - State vector angle
theta = 2*pi/10;

% Quantum Noise Analysis
Noise_analysis


function [rho_out,psi_out] = rho_ch(r)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
GHZ = 1/sqrt(2).*[1 0 0 0 0 0 0 1]';
Bell = 1/sqrt(2).*[1 0 0 1]';
q = log2(r);
H = (q-4)/2;

k = 0;
rho_out = GHZ*conj(transpose(GHZ));
psi_out = GHZ;
while(k<H)
    rho_out = kron(rho_out,Bell*conj(transpose(Bell)));
    psi_out = kron(psi_out,Bell);
    k=k+1;
end

end


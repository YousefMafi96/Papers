function [U] = U_Alice(r)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
I = eye(2);
H = 1/sqrt(2).*[1 1;1 -1];
CNOT = [1 0 0 0 0 0 0 0
        0 1 0 0 0 0 0 0
        0 0 1 0 0 0 0 0
        0 0 0 1 0 0 0 0
        0 0 0 0 0 1 0 0
        0 0 0 0 1 0 0 0
        0 0 0 0 0 0 0 1
        0 0 0 0 0 0 1 0];
U1 = kron(H,eye(8))*kron(CNOT, I);
U2 = zeros(16);
U2(1,1)=1;U2(2,2)=1;U2(8,3)=1;U2(7,4)=1;U2(5,5)=1;U2(6,6)=1;U2(4,7)=1;U2(3,8)=1;
U2(9,9)=1;U2(10,10)=-1;U2(16,11)=1;U2(15,12)=-1;U2(13,13)=-1;U2(14,14)=1;U2(12,15)=-1;U2(11,16)=1;

U = kron(U2,eye(r/16))*kron(U1,eye(r/16));


end


function [U] = U_Charlie(r)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
H = 1/sqrt(2).*[1 1;1 -1];
q = log2(r);

U_C = eye(r);
U_C(pow2(q-2)+2:2:r/2,pow2(q-2)+2:2:r/2)=-1*U_C(pow2(q-2)+2:2:r/2,pow2(q-2)+2:2:r/2);
U_C(pow2(q-2)+2+pow2(q-1):2:r/2+pow2(q-1),pow2(q-2)+2+pow2(q-1):2:r/2+pow2(q-1))=-1*U_C(pow2(q-2)+2+pow2(q-1):2:r/2+pow2(q-1),pow2(q-2)+2+pow2(q-1):2:r/2+pow2(q-1));

U = U_C*kron(kron(eye(2),H),eye(r/4));
end

